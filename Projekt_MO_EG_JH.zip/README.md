# Projekt optymalizacja :rocket:

Repozytorium jest poświęcone projektowi w ramach przedmiotu *Metody Optymalizacji*. Zaimplementowane zostały algorytmy Quasi-Newton'owskie: BFGS i DFP.

## Struktura repozytorium :artificial_satellite:

```text
Projekt_optymalizacja/
├── env/
├── main/
│   ├── main.py
│   ├── main1.py
│   ├── main2.py
│   ├── algorithms.py
│   └── draw_func.py
├── requirements.txt
└── README.md
```



## Instalacja :bulb:

Autorzy zakładają, że pobierający stosują system operacyjny Linux lub korzystają z powłoki Git Bash dla systemów Windows. W przypadku innej konfiguracji prosimy o kontakt.

W pierwszej kolejności należy sklonować repozytorium na swoją maszynę (zalecane użycie SSH) z wykorzystaniem komendy: 

```bash
git clone git@github.com:emagif/Projekt_optymalizacja.git
```

Po skopiowaniu repozytorium należy udać się wewnątrz drzewa projektu: 

```bash 
cd Projekt_optymalizacja
```

i utworzyć wirtualne środowisko: 

```bash
python -m venv env
```
Po utworzeniu środowiska należy je aktywować: 

```bash
source env/Scripts/activate
```

W pliku ```requirements.txt``` znajdują się nazwy wszystkich bibliotek zastosowanych przez autorów projektu, aby zainstalować stosowane przez autorów wersje bibliotek należy użyć komendy: 

```bash 
pip install -r requirements.txt
```
Nie jest sugerowane instalowanie "z ręki" tych samych pakietów, które są zawarte w ```requirements.txt```, może to skutkować instalacją niekompatybilnych wersji bibliotek. Najlepiej zastosować się do powyższych zaleceń. 


## Użytkowanie aplikacji :hammer:

Wszelkie algorytmy i funkcje związane z podstawowymi obliczeniami (obliczanie wartości funkcji celu, obliczenie gradientów w punkcie), zostały zaimplementowane w pliku ```algorithms.py```. Funkcje obliczające wartości funkcji celu oraz gradientu funkcji celu zostały nazwane z wykorzystaniem odpowiednich przedrostków i zrozumiałych aliasów, np.: 

```bash
def rosenbrock_f(xk):
    return (1-xk[0])**2 + 100*(xk[1] - xk[0]**2)**2
```

czy,

```bash 
def grad_himmelblau(xk): 
    grad_x1 = 4 * xk[0] * ((xk[0]**2) + xk[1] - 11) + 2 * (xk[0] + (xk[1]**2) - 7)
    grad_x2 = 4 * xk[1] * (xk[0] + (xk[1]**2)-7) + 2 * ((xk[0]**2) + xk[1] - 11)
    return np.array([grad_x1, grad_x2])
```
Następnie zaimplementowane zostały metody Quasi-Newtonowskie (BFGS oraz DFP). Struktury funkcji są następujące: 

```bash 
def Quasi_Newton_BFGS(start_x1, start_x2, functions):
    .
    .
    .
    return (functions[0](xk), xk[0], xk[1], iter_num, f_values, path)
```
zatem funkcja przyjmuje dwa punkty startowe, funkcję celu oraz jej gradient.


```bash
def Quasi_Newton_DFP(start_x1, start_x2, functions):
    .
    .
    .
    return (functions[0](xk), xk[0], xk[1], len(path), f_values, path)
```
Powyższa funkcja implementująca wariację DFP, przyjmuje dokładnie te same argument i zwraca te same wartości po wykonaniu obliczeń. 

Wszelkie funkcje związane z rysowaniem wykresów zostały zaimplementowane w pliku ```draw_func.py```. Funkcje rysujące zostały nazwane z wykorzystaniem odpowiednich przedrostków i zrozumiałych aliasów, np.: 

```bash
def drawFValuesLog(f_values1, f_values2, f_values3, f_values4,
                   label1='Metoda 1',
                   label2='Metoda 2',
                   label3='Metoda 3', 
                   label4='Metoda 4'):
    .
    .
    .              
```
czy,

```bash
def himmelblau_f_draw_contour_3_bez_ograniczen(x1, x2, levels, resolution,
                                path1, path2, path3, path4):
    .
    .
    . 
 ```


## Autorzy :brain:

Autorami projektu są **Jakub Hinca** oraz **Emanuel Gifuni**. 

*Automatyka, robotyka i systemy sterowania - I semestr studiów magisterskich.*